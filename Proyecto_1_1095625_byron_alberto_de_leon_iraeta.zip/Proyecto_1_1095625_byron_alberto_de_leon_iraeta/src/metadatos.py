import os
import stat
from datetime import datetime


def obtener_metadatos(ruta_archivo):
    """
    Obtiene los metadatos principales
    de un archivo.
    """

    if not os.path.exists(ruta_archivo):
        return None

    informacion = os.stat(ruta_archivo)

    nombre = os.path.basename(ruta_archivo)

    extension = os.path.splitext(
        ruta_archivo
    )[1]

    ruta_absoluta = os.path.abspath(
        ruta_archivo
    )

    tamanio_bytes = informacion.st_size

    fecha_modificacion = datetime.fromtimestamp(
        informacion.st_mtime
    ).strftime("%Y-%m-%d %H:%M:%S")

    fecha_creacion = datetime.fromtimestamp(
        informacion.st_ctime
    ).strftime("%Y-%m-%d %H:%M:%S")

    permisos = stat.filemode(
        informacion.st_mode
    )

    return {
        "nombre": nombre,
        "ruta": ruta_absoluta,
        "extension": extension,
        "tamanio": tamanio_bytes,
        "fecha_creacion": fecha_creacion,
        "fecha_modificacion": fecha_modificacion,
        "permisos": permisos
    }


def listar_archivos_sistema():
    """
    Retorna los archivos principales
    utilizados por el sistema.
    """

    archivos = [
        "data/registros.csv",
        "config/configuracion.json",
        "indices/indice_id.json",
        "indices/indice_categoria.json",
        "indices/indice_estado.json",
        "indices/tabla_hash.json",
        "indices/hashes.json",
        "logs/sistema.log"
    ]

    return archivos