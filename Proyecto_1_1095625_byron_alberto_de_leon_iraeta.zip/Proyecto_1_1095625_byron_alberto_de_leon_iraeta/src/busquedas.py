from src.archivos import leer_registros


def busqueda_secuencial_por_id(id_buscado):
    """
    Busca un registro recorriendo secuencialmente
    el archivo principal.

    Retorna:
    - registro encontrado
    - cantidad de registros recorridos
    """

    registros = leer_registros()

    recorridos = 0

    for registro in registros:

        recorridos += 1

        if registro["id"] == id_buscado:
            return registro, recorridos

    return None, recorridos


def busqueda_por_atributo(atributo, valor):
    """
    Busca todos los registros que coincidan
    con un atributo determinado.
    """

    registros = leer_registros()

    resultados = []

    for registro in registros:

        if registro.get(atributo, "").lower() == valor.lower():
            resultados.append(registro)

    return resultados