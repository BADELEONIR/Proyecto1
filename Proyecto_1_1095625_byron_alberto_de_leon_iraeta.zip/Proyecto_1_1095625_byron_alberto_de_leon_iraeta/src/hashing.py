import json
import os

from src.archivos import leer_registros


ARCHIVO_TABLA_HASH = "indices/tabla_hash.json"

TAMANIO_TABLA = 10


def funcion_hash(id_registro):
    """
    Función hash sencilla.

    Convierte el ID a número y calcula
    el residuo entre el ID y el tamaño
    de la tabla.

    Ejemplo:
    1001 % 10 = 1
    """

    return int(id_registro) % TAMANIO_TABLA


def crear_tabla_hash():
    """
    Crea una tabla hash vacía.

    Cada posición contiene una lista para
    permitir el manejo de colisiones mediante
    encadenamiento.
    """

    tabla = {}

    for posicion in range(TAMANIO_TABLA):
        tabla[str(posicion)] = []

    return tabla


def generar_tabla_hash():
    """
    Genera la tabla hash utilizando todos
    los registros almacenados en el CSV.
    """

    os.makedirs(
        "indices",
        exist_ok=True
    )

    registros = leer_registros()

    tabla = crear_tabla_hash()

    for registro in registros:

        posicion = funcion_hash(
            registro["id"]
        )

        tabla[str(posicion)].append(
            registro["id"]
        )

    with open(
        ARCHIVO_TABLA_HASH,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            tabla,
            archivo,
            indent=4,
            ensure_ascii=False
        )

    return tabla


def cargar_tabla_hash():
    """
    Carga la tabla hash almacenada.
    """

    if not os.path.exists(
        ARCHIVO_TABLA_HASH
    ):
        return generar_tabla_hash()

    with open(
        ARCHIVO_TABLA_HASH,
        "r",
        encoding="utf-8"
    ) as archivo:

        return json.load(archivo)


def buscar_por_hash(id_buscado):
    """
    Busca un registro utilizando
    la tabla hash.

    Primero calcula la posición correspondiente
    y posteriormente revisa únicamente
    los IDs almacenados en esa posición.
    """

    tabla = cargar_tabla_hash()

    posicion = funcion_hash(
        id_buscado
    )

    ids_en_posicion = tabla.get(
        str(posicion),
        []
    )

    if id_buscado not in ids_en_posicion:
        return None, posicion

    registros = leer_registros()

    for registro in registros:

        if registro["id"] == id_buscado:
            return registro, posicion

    return None, posicion


def obtener_colisiones():
    """
    Identifica las posiciones que contienen
    más de un ID.
    """

    tabla = cargar_tabla_hash()

    colisiones = {}

    for posicion, ids in tabla.items():

        if len(ids) > 1:
            colisiones[posicion] = ids

    return colisiones