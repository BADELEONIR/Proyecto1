class ValidadorRegistros:
    def __init__(self):
        self.bitacora_errores = []

    def verificar_codigo(self, codigo):
        codigo_limpio = str(codigo or "").strip()
        
        if not codigo_limpio:
            return "El código no puede estar en blanco."
        
        if not codigo_limpio.isdigit():
            return "El código debe contener únicamente números enteros positivos."
            
        return None

    def verificar_fecha(self, fecha_str):
       
        fecha_limpia = str(fecha_str or "").strip()
        
       
        if len(fecha_limpia) != 10:
            return "El formato de fecha es incorrecto. Utilice AAAA-MM-DD."
            
        
        if fecha_limpia[4] != '-' or fecha_limpia[7] != '-':
            return "El formato de fecha es incorrecto. Utilice AAAA-MM-DD."
            
        
        a = fecha_limpia[0:4]
        mes = fecha_limpia[5:7]
        dia = fecha_limpia[8:10]
        
        if not (a.isdigit() and mes.isdigit() and dia.isdigit()):
            return "El formato de fecha debe contener solo nmeros en las secciones de año, mes y día."
            
        return None