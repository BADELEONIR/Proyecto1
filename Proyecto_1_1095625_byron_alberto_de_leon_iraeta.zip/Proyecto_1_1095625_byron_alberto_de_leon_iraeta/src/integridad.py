import hashlib
import json
import os


ARCHIVO_HASHES = "indices/hashes.json"

ARCHIVOS_PROTEGIDOS = [
    "data/registros.csv",
    "config/configuracion.json"
]


def calcular_sha256(ruta_archivo):
    """
    Calcula el SHA-256 de un archivo.
    """

    sha256 = hashlib.sha256()

    with open(ruta_archivo, "rb") as archivo:

        while True:

            bloque = archivo.read(4096)

            if not bloque:
                break

            sha256.update(bloque)

    return sha256.hexdigest()


def guardar_hashes():
    """
    Calcula y almacena los hashes actuales
    de los archivos protegidos.
    """

    os.makedirs("indices", exist_ok=True)

    hashes = {}

    for ruta in ARCHIVOS_PROTEGIDOS:

        if os.path.exists(ruta):

            hashes[ruta] = calcular_sha256(ruta)

    with open(
        ARCHIVO_HASHES,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            hashes,
            archivo,
            indent=4,
            ensure_ascii=False
        )

    return hashes


def cargar_hashes():
    """
    Recupera los hashes previamente registrados.
    """

    if not os.path.exists(ARCHIVO_HASHES):
        return {}

    with open(
        ARCHIVO_HASHES,
        "r",
        encoding="utf-8"
    ) as archivo:

        return json.load(archivo)


def verificar_integridad():
    """
    Compara el hash registrado contra
    el hash actual de cada archivo.
    """

    hashes_guardados = cargar_hashes()

    resultados = []

    for ruta in ARCHIVOS_PROTEGIDOS:

        if not os.path.exists(ruta):

            resultados.append({
                "archivo": ruta,
                "estado": "NO EXISTE",
                "hash_guardado": hashes_guardados.get(ruta),
                "hash_actual": None
            })

            continue

        hash_actual = calcular_sha256(ruta)

        hash_guardado = hashes_guardados.get(ruta)

        if hash_guardado is None:

            estado = "SIN HASH REGISTRADO"

        elif hash_actual == hash_guardado:

            estado = "OK"

        else:

            estado = "ALTERADO"

        resultados.append({
            "archivo": ruta,
            "estado": estado,
            "hash_guardado": hash_guardado,
            "hash_actual": hash_actual
        })

    return resultados