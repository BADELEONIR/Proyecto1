import os
import shutil
from datetime import datetime


CARPETA_BACKUPS = "backups"

ARCHIVOS_RESPALDO = [
    "data/registros.csv",
    "config/configuracion.json",
    "exports/registros.xml"
]


def crear_respaldo():
    """
    Crea un respaldo de los archivos principales
    del sistema.

    Cada respaldo se almacena en una carpeta
    identificada mediante fecha y hora.
    """

    os.makedirs(
        CARPETA_BACKUPS,
        exist_ok=True
    )

    fecha_hora = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    nombre_backup = (
        f"backup_{fecha_hora}"
    )

    ruta_backup = os.path.join(
        CARPETA_BACKUPS,
        nombre_backup
    )

    os.makedirs(
        ruta_backup,
        exist_ok=True
    )

    archivos_copiados = []

    for ruta_original in ARCHIVOS_RESPALDO:

        if os.path.exists(ruta_original):

            nombre_archivo = os.path.basename(
                ruta_original
            )

            ruta_destino = os.path.join(
                ruta_backup,
                nombre_archivo
            )

            shutil.copy2(
                ruta_original,
                ruta_destino
            )

            archivos_copiados.append(
                nombre_archivo
            )

    return (
        nombre_backup,
        ruta_backup,
        archivos_copiados
    )


def listar_respaldos():
    """
    Retorna todos los respaldos disponibles.
    """

    os.makedirs(
        CARPETA_BACKUPS,
        exist_ok=True
    )

    respaldos = []

    for elemento in os.listdir(
        CARPETA_BACKUPS
    ):

        ruta = os.path.join(
            CARPETA_BACKUPS,
            elemento
        )

        if (
            os.path.isdir(ruta)
            and elemento.startswith("backup_")
        ):

            respaldos.append(elemento)

    respaldos.sort(reverse=True)

    return respaldos


def restaurar_respaldo(nombre_backup):
    """
    Restaura los archivos almacenados
    dentro de un respaldo.
    """

    ruta_backup = os.path.join(
        CARPETA_BACKUPS,
        nombre_backup
    )

    if not os.path.exists(ruta_backup):
        return False, []

    archivos_restaurados = []

    destinos = {
        "registros.csv":
            "data/registros.csv",

        "configuracion.json":
            "config/configuracion.json",

        "registros.xml":
            "exports/registros.xml"
    }

    for nombre_archivo, destino in destinos.items():

        origen = os.path.join(
            ruta_backup,
            nombre_archivo
        )

        if os.path.exists(origen):

            carpeta_destino = os.path.dirname(
                destino
            )

            os.makedirs(
                carpeta_destino,
                exist_ok=True
            )

            shutil.copy2(
                origen,
                destino
            )

            archivos_restaurados.append(
                destino
            )

    return True, archivos_restaurados