import json
import os

from src.archivos import leer_registros


CARPETA_INDICES = "indices"

ARCHIVO_INDICE_ID = "indices/indice_id.json"
ARCHIVO_INDICE_CATEGORIA = "indices/indice_categoria.json"
ARCHIVO_INDICE_ESTADO = "indices/indice_estado.json"


def crear_carpeta_indices():

    os.makedirs(
        CARPETA_INDICES,
        exist_ok=True
    )


def generar_indice_id():
    """
    Genera un índice:
    
    ID -> posición del registro
    """

    crear_carpeta_indices()

    registros = leer_registros()

    indice = {}

    for posicion, registro in enumerate(registros):

        indice[registro["id"]] = posicion

    with open(
        ARCHIVO_INDICE_ID,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            indice,
            archivo,
            indent=4,
            ensure_ascii=False
        )

    return indice


def generar_indice_categoria():
    """
    Genera un índice invertido:

    categoría -> lista de IDs
    """

    crear_carpeta_indices()

    registros = leer_registros()

    indice = {}

    for registro in registros:

        categoria = registro["categoria"]

        if categoria not in indice:
            indice[categoria] = []

        indice[categoria].append(
            registro["id"]
        )

    with open(
        ARCHIVO_INDICE_CATEGORIA,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            indice,
            archivo,
            indent=4,
            ensure_ascii=False
        )

    return indice


def generar_indice_estado():
    """
    Genera un índice por estado.

    estado -> lista de IDs
    """

    crear_carpeta_indices()

    registros = leer_registros()

    indice = {}

    for registro in registros:

        estado = registro["estado"]

        if estado not in indice:
            indice[estado] = []

        indice[estado].append(
            registro["id"]
        )

    with open(
        ARCHIVO_INDICE_ESTADO,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            indice,
            archivo,
            indent=4,
            ensure_ascii=False
        )

    return indice


def generar_todos_los_indices():

    generar_indice_id()
    generar_indice_categoria()
    generar_indice_estado()


def cargar_indice(ruta):

    if not os.path.exists(ruta):
        return {}

    with open(
        ruta,
        "r",
        encoding="utf-8"
    ) as archivo:

        return json.load(archivo)


def buscar_por_indice_id(id_buscado):
    """
    Localiza el registro utilizando primero
    el índice por ID.
    """

    indice = cargar_indice(
        ARCHIVO_INDICE_ID
    )

    if id_buscado not in indice:
        return None

    posicion = indice[id_buscado]

    registros = leer_registros()

    if posicion >= len(registros):
        return None

    return registros[posicion]


def buscar_por_indice_categoria(categoria):

    indice = cargar_indice(
        ARCHIVO_INDICE_CATEGORIA
    )

    ids = indice.get(categoria, [])

    registros = leer_registros()

    resultados = []

    for registro in registros:

        if registro["id"] in ids:
            resultados.append(registro)

    return resultados


def buscar_por_indice_estado(estado):

    indice = cargar_indice(
        ARCHIVO_INDICE_ESTADO
    )

    ids = indice.get(estado, [])

    registros = leer_registros()

    resultados = []

    for registro in registros:

        if registro["id"] in ids:
            resultados.append(registro)

    return resultados