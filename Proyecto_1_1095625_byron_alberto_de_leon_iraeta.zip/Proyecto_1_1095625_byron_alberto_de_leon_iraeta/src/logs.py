import os
from datetime import datetime


ARCHIVO_LOG = "logs/sistema.log"


def preparar_log():
    """
    Crea la carpeta y el archivo de log
    si todavía no existen.
    """

    os.makedirs("logs", exist_ok=True)

    if not os.path.exists(ARCHIVO_LOG):

        with open(
            ARCHIVO_LOG,
            "w",
            encoding="utf-8"
        ) as archivo:

            archivo.write(
                "=== LOG DEL SISTEMA ===\n"
            )


def registrar_log(operacion, descripcion):
    """
    Registra una operación en el archivo log.

    Formato:
    fecha | hora | operación | descripción
    """

    preparar_log()

    ahora = datetime.now()

    fecha = ahora.strftime("%Y-%m-%d")
    hora = ahora.strftime("%H:%M:%S")

    linea = (
        f"{fecha} | "
        f"{hora} | "
        f"{operacion} | "
        f"{descripcion}\n"
    )

    with open(
        ARCHIVO_LOG,
        "a",
        encoding="utf-8"
    ) as archivo:

        archivo.write(linea)


def leer_logs():
    """
    Recupera todas las líneas almacenadas
    en el archivo de log.
    """

    preparar_log()

    with open(
        ARCHIVO_LOG,
        "r",
        encoding="utf-8"
    ) as archivo:

        return archivo.readlines()