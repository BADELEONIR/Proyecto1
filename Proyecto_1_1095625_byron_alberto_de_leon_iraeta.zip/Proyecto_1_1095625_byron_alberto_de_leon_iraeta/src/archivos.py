import csv
import os
import xml.etree.ElementTree as ET
from src.utilidades import ValidadorRegistros

ARCHIVO_REGISTROS = "data/registros.csv"

CAMPOS = [
    "id",
    "nombre",
    "categoria",
    "descripcion",
    "fecha",
    "estado"
]


def crear_archivo_si_no_existe():
    """
    Crea el archivo CSV con sus encabezados
    únicamente si todavía no existe.
    """

    os.makedirs("data", exist_ok=True)

    if not os.path.exists(ARCHIVO_REGISTROS):
        with open(
            ARCHIVO_REGISTROS,
            "w",
            newline="",
            encoding="utf-8"
        ) as archivo:

            escritor = csv.DictWriter(
                archivo,
                fieldnames=CAMPOS
            )

            escritor.writeheader()


def leer_registros():
    """
    Lee todos los registros almacenados
    en el archivo CSV.
    """

    crear_archivo_si_no_existe()

    registros = []

    with open(
        ARCHIVO_REGISTROS,
        "r",
        newline="",
        encoding="utf-8"
    ) as archivo:

        lector = csv.DictReader(archivo)

        for registro in lector:
            registros.append(registro)

    return registros


def existe_id(id_registro):
    """
    Verifica si ya existe un registro
    con el ID recibido.
    """

    registros = leer_registros()

    for registro in registros:

        if registro["id"] == id_registro:
            return True

    return False


def agregar_registro(registro):
    """
    Agrega un nuevo registro al archivo CSV.

    Retorna False si el ID ya existe.
    Retorna True si se agregó correctamente.
    """
    validador = ValidadorRegistros()
    
    
    error_id = validador.verificar_codigo(registro.get("id"))
    error_fecha = validador.verificar_fecha(registro.get("fecha"))
    
    if error_id or error_fecha:
        print("\nNo se pudo agregar el registro:")
        if error_id:
            print(f" - {error_id}")
        if error_fecha:
            print(f" - {error_fecha}")
        return False
    
    crear_archivo_si_no_existe()

    if existe_id(registro["id"]):
        return False

    with open(
        ARCHIVO_REGISTROS,
        "a",
        newline="",
        encoding="utf-8"
    ) as archivo:

        escritor = csv.DictWriter(
            archivo,
            fieldnames=CAMPOS
        )

        escritor.writerow(registro)

    return True


def buscar_registro_por_id(id_registro):
    """
    Busca un registro utilizando su ID.

    Esta primera implementación utiliza
    búsqueda secuencial.
    """

    registros = leer_registros()

    for registro in registros:

        if registro["id"] == id_registro:
            return registro

    return None


def actualizar_registro(id_registro, nuevos_datos):
    """
    Actualiza un registro existente.

    Como estamos trabajando con CSV,
    se leen los registros, se modifica
    el correspondiente y posteriormente
    se reescribe el archivo.
    """
    validador = ValidadorRegistros()
    
   
    error_fecha = validador.verificar_fecha(nuevos_datos.get("fecha"))
    
    if error_fecha:
        print("\n[ERROR DE VALIDACIÓN] No se pudo actualizar el registro:")
        print(f" - {error_fecha}")
        return False

    registros = leer_registros()

    encontrado = False

    for registro in registros:

        if registro["id"] == id_registro:

            registro["nombre"] = nuevos_datos["nombre"]
            registro["categoria"] = nuevos_datos["categoria"]
            registro["descripcion"] = nuevos_datos["descripcion"]
            registro["fecha"] = nuevos_datos["fecha"]
            registro["estado"] = nuevos_datos["estado"]

            encontrado = True
            break

    if not encontrado:
        return False

    with open(
        ARCHIVO_REGISTROS,
        "w",
        newline="",
        encoding="utf-8"
    ) as archivo:

        escritor = csv.DictWriter(
            archivo,
            fieldnames=CAMPOS
        )

        escritor.writeheader()
        escritor.writerows(registros)

    return True


def eliminar_registro(id_registro):
    """
    Elimina un registro del archivo CSV.
    """

    registros = leer_registros()

    nuevos_registros = []

    encontrado = False

    for registro in registros:

        if registro["id"] == id_registro:
            encontrado = True
        else:
            nuevos_registros.append(registro)

    if not encontrado:
        return False

    with open(
        ARCHIVO_REGISTROS,
        "w",
        newline="",
        encoding="utf-8"
    ) as archivo:

        escritor = csv.DictWriter(
            archivo,
            fieldnames=CAMPOS
        )

        escritor.writeheader()
        escritor.writerows(nuevos_registros)

    return True



def exportar_a_xml():
    """
    Exporta todos los registros almacenados
    en el CSV a un archivo XML.
    """

    registros = leer_registros()

    os.makedirs(
        "exports",
        exist_ok=True
    )

    raiz = ET.Element("registros")

    for registro in registros:

        elemento_registro = ET.SubElement(
            raiz,
            "registro"
        )

        for campo in CAMPOS:

            elemento_campo = ET.SubElement(
                elemento_registro,
                campo
            )

            elemento_campo.text = registro[campo]

    arbol = ET.ElementTree(raiz)

    ET.indent(
        arbol,
        space="    "
    )

    ruta_xml = "exports/registros.xml"

    arbol.write(
        ruta_xml,
        encoding="utf-8",
        xml_declaration=True
    )

    return ruta_xml