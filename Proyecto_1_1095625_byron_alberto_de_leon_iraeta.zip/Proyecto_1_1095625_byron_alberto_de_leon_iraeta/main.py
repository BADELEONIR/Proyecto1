from src.archivos import (
    crear_archivo_si_no_existe,
    leer_registros,
    agregar_registro,
    buscar_registro_por_id,
    actualizar_registro,
    eliminar_registro,
    exportar_a_xml
)

from src.busquedas import (
    busqueda_secuencial_por_id,
    busqueda_por_atributo
)

from src.indices import (
    generar_todos_los_indices,
    cargar_indice,
    buscar_por_indice_id,
    buscar_por_indice_categoria,
    buscar_por_indice_estado,
    ARCHIVO_INDICE_ID,
    ARCHIVO_INDICE_CATEGORIA,
    ARCHIVO_INDICE_ESTADO
)

from src.hashing import (
    generar_tabla_hash,
    buscar_por_hash,
    obtener_colisiones,
    funcion_hash
)

from src.integridad import (
    guardar_hashes,
    verificar_integridad
)

from src.logs import (
    preparar_log,
    registrar_log,
    leer_logs
)

from src.pila import PilaOperaciones

pila_operaciones = PilaOperaciones()

from src.metadatos import (
    obtener_metadatos,
    listar_archivos_sistema
)

from src.respaldos import (
    crear_respaldo,
    listar_respaldos,
    restaurar_respaldo
)

def mostrar_registro(registro):
    print("\n-----------------------------")
    print(f"ID:          {registro['id']}")
    print(f"Nombre:      {registro['nombre']}")
    print(f"Categoría:   {registro['categoria']}")
    print(f"Descripción: {registro['descripcion']}")
    print(f"Fecha:       {registro['fecha']}")
    print(f"Estado:      {registro['estado']}")
    print("-----------------------------")


def registrar_informacion():

    print("\n=== REGISTRAR INFORMACIÓN ===")

    registro = {
        "id": input("ID: "),
        "nombre": input("Nombre: "),
        "categoria": input("Categoría: "),
        "descripcion": input("Descripción: "),
        "fecha": input("Fecha (AAAA-MM-DD): "),
        "estado": input("Estado: ")
    }

    resultado = agregar_registro(registro)

    if resultado:

        generar_todos_los_indices()
        generar_tabla_hash()
        guardar_hashes()

        registrar_log(
            "CREATE",
            f"Registro creado con ID {registro['id']}"
        )

        pila_operaciones.push(
            f"CREATE - Registro {registro['id']}"
        )

        print("\nRegistro almacenado correctamente.")
        print("Índices actualizados correctamente.")
        print("Tabla hash actualizada correctamente.")
        print("Hashes de integridad actualizados.")

    else:

        registrar_log(
            "CREATE_ERROR",
            f"Intento de registrar ID duplicado {registro['id']}"
        )

        print("\nERROR: El ID ingresado ya existe.")


def mostrar_todos():

    print("\n=== REGISTROS ALMACENADOS ===")

    registros = leer_registros()

    if len(registros) == 0:
        print("No existen registros.")
        return

    for registro in registros:
        mostrar_registro(registro)


def buscar_por_id():

    print("\n=== BÚSQUEDA SECUENCIAL POR ID ===")

    id_registro = input("Ingrese el ID: ")

    registro, recorridos = busqueda_secuencial_por_id(id_registro)

    if registro is None:
        print("\nRegistro no encontrado.")

        registrar_log(
            "SEARCH",
            f"Búsqueda secuencial sin resultado para ID {id_registro}"
        )
    else:
        mostrar_registro(registro)

        registrar_log(
            "SEARCH",
            f"Búsqueda secuencial exitosa para ID {id_registro}"
        )

        pila_operaciones.push(
            f"SEARCH - Registro {id_registro}"
        )

    print(f"\nRegistros recorridos: {recorridos}")


def actualizar():

    print("\n=== ACTUALIZAR REGISTRO ===")

    id_registro = input("Ingrese el ID: ")

    registro = buscar_registro_por_id(id_registro)

    
    if registro is None:
        print("\nRegistro no encontrado.")
        return

    print("\nInformación actual:")
    mostrar_registro(registro)

    print("\nIngrese la nueva información:")

    nuevos_datos = {
        "nombre": input("Nombre: "),
        "categoria": input("Categoría: "),
        "descripcion": input("Descripción: "),
        "fecha": input("Fecha (AAAA-MM-DD): "),
        "estado": input("Estado: ")
    }

    if actualizar_registro(id_registro, nuevos_datos):
        generar_todos_los_indices()
        generar_tabla_hash()
        guardar_hashes()

        registrar_log(
            "UPDATE",
            f"Registro actualizado con ID {id_registro}"
        )

        pila_operaciones.push(
            f"UPDATE - Registro {id_registro}"
        )

        print("\nRegistro actualizado correctamente.")
        print("Índices actualizados correctamente.")
        print("Tabla hash actualizada correctamente.")
        print("Hashes de integridad actualizados.")
    else:

        registrar_log(
            "UPDATE_ERROR",
            f"No fue posible actualizar ID {id_registro}"
        )

        print("\nNo fue posible actualizar el registro.")


def eliminar():

    print("\n=== ELIMINAR REGISTRO ===")

    id_registro = input("Ingrese el ID: ")

    registro = buscar_registro_por_id(id_registro)

    if registro is None:
        print("\nRegistro no encontrado.")
        return

    mostrar_registro(registro)

    confirmacion = input(
        "\n¿Está seguro de eliminar este registro? (s/n): "
    ).lower()

    if confirmacion == "s":

        if eliminar_registro(id_registro):
            generar_todos_los_indices()
            generar_tabla_hash()
            guardar_hashes()

            registrar_log(
                "DELETE",
                f"Registro eliminado con ID {id_registro}"
            )

            pila_operaciones.push(
                f"DELETE - Registro {id_registro}"
            )

            print("\nRegistro eliminado correctamente.")
            print("Índices actualizados correctamente.")
            print("Tabla hash actualizada correctamente.")
            print("Hashes de integridad actualizados.")

    else:

        registrar_log(
            "DELETE_CANCEL",
            f"Eliminación cancelada para ID {id_registro}"
        )

        print("\nOperación cancelada.")

def buscar_por_atributo():

    print("\n=== BUSCAR POR ATRIBUTO ===")

    print("1. Nombre")
    print("2. Categoría")
    print("3. Estado")

    opcion = input("Seleccione el atributo: ")

    atributos = {
        "1": "nombre",
        "2": "categoria",
        "3": "estado"
    }

    if opcion not in atributos:
        print("\nOpción inválida.")
        return

    atributo = atributos[opcion]

    valor = input(f"Ingrese {atributo}: ")

    resultados = busqueda_por_atributo(
        atributo,
        valor
    )

    if len(resultados) == 0:
        print("\nNo se encontraron registros.")
        return

    print(
        f"\nSe encontraron {len(resultados)} registro(s):"
    )

    for registro in resultados:
        mostrar_registro(registro)

def mostrar_indice_principal():

    print("\n=== ÍNDICE PRINCIPAL ===")

    indice = cargar_indice(
        ARCHIVO_INDICE_ID
    )

    if not indice:
        print("El índice está vacío o no existe.")
        return

    for id_registro, posicion in indice.items():

        print(
            f"ID: {id_registro} -> "
            f"Posición: {posicion}"
        )


def mostrar_indice_invertido():

    print("\n=== ÍNDICE INVERTIDO POR CATEGORÍA ===")

    indice = cargar_indice(
        ARCHIVO_INDICE_CATEGORIA
    )

    if not indice:
        print("El índice está vacío o no existe.")
        return

    for categoria, ids in indice.items():

        print(
            f"{categoria} -> {ids}"
        )


def buscar_utilizando_indice():

    print("\n=== BÚSQUEDA UTILIZANDO ÍNDICES ===")

    print("1. ID")
    print("2. Categoría")
    print("3. Estado")

    opcion = input(
        "Seleccione el tipo de búsqueda: "
    )

    if opcion == "1":

        id_registro = input(
            "Ingrese el ID: "
        )

        registro = buscar_por_indice_id(
            id_registro
        )

        if registro is None:
            print("\nRegistro no encontrado.")
        else:
            mostrar_registro(registro)

    elif opcion == "2":

        categoria = input(
            "Ingrese la categoría: "
        )

        resultados = buscar_por_indice_categoria(
            categoria
        )

        if not resultados:
            print("\nNo se encontraron registros.")
        else:
            for registro in resultados:
                mostrar_registro(registro)

    elif opcion == "3":

        estado = input(
            "Ingrese el estado: "
        )

        resultados = buscar_por_indice_estado(
            estado
        )

        if not resultados:
            print("\nNo se encontraron registros.")
        else:
            for registro in resultados:
                mostrar_registro(registro)

    else:
        print("\nOpción inválida.")


def reconstruir_indices():

    generar_todos_los_indices()

    registrar_log(
        "INDEX",
        "Reconstrucción manual de todos los índices"
    )

    print(
        "\nTodos los índices fueron "
        "reconstruidos correctamente."
    )

def mostrar_tabla_hash():

    print("\n=== TABLA HASH ===")

    tabla = generar_tabla_hash()

    for posicion, ids in tabla.items():

        if ids:
            contenido = " -> ".join(ids)
        else:
            contenido = "VACÍO"

        print(
            f"Posición {posicion}: {contenido}"
        )

def buscar_utilizando_hash():

    print("\n=== BÚSQUEDA MEDIANTE HASHING ===")

    id_registro = input(
        "Ingrese el ID: "
    )

    try:

        posicion = funcion_hash(
            id_registro
        )

    except ValueError:

        print(
            "\nERROR: El ID debe ser numérico."
        )

        return

    print(
        f"\nPosición calculada: {posicion}"
    )

    registro, posicion = buscar_por_hash(
        id_registro
    )

    if registro is None:

        print(
            "Registro no encontrado."
        )

    else:

        mostrar_registro(registro)

def mostrar_colisiones():

    print("\n=== COLISIONES ===")

    colisiones = obtener_colisiones()

    if not colisiones:

        print(
            "Actualmente no existen colisiones."
        )

        return

    for posicion, ids in colisiones.items():

        print(
            f"Posición {posicion}: {ids}"
        )


def registrar_integridad():

    print("\n=== REGISTRAR INTEGRIDAD ===")

    hashes = guardar_hashes()

    registrar_log(
        "INTEGRITY_REGISTER",
        "Hashes SHA-256 registrados"
    )

    if not hashes:

        print(
            "\nNo existen archivos para registrar."
        )
        return

    print("\nHashes SHA-256 registrados:")

    for archivo, hash_archivo in hashes.items():

        print(f"\nArchivo: {archivo}")
        print(f"SHA-256: {hash_archivo}")


def consultar_integridad():

    print("\n=== VERIFICACIÓN DE INTEGRIDAD ===")

    resultados = verificar_integridad()

    for resultado in resultados:

        registrar_log(
            "INTEGRITY_CHECK",
            f"{resultado['archivo']} -> {resultado['estado']}"
        )

        print("\n--------------------------------")

        print(
            f"Archivo: {resultado['archivo']}"
        )

        print(
            f"Estado: {resultado['estado']}"
        )

        print(
            f"Hash registrado: "
            f"{resultado['hash_guardado']}"
        )

        print(
            f"Hash actual: "
            f"{resultado['hash_actual']}"
        )

    print("\n--------------------------------")



def consultar_logs():

    print("\n=== LOG DEL SISTEMA ===")

    lineas = leer_logs()

    if len(lineas) <= 1:

        print("\nNo existen operaciones registradas.")
        return

    for linea in lineas:
        print(linea, end="")


def mostrar_pila():

    print("\n=== PILA DE OPERACIONES ===")

    if pila_operaciones.esta_vacia():

        print("\nLa pila está vacía.")
        return

    elementos = pila_operaciones.obtener_elementos()

    print("\nTOP")
    print(" │")
    print(" ▼")

    for operacion in elementos:

        print(f"[ {operacion} ]")

    print("\nCantidad de operaciones:",
          pila_operaciones.tamanio())

def consultar_top():

    print("\n=== TOP DE LA PILA ===")

    operacion = pila_operaciones.peek()

    if operacion is None:

        print("\nLa pila está vacía.")

    else:

        print(
            f"\nÚltima operación: {operacion}"
        )

def retirar_operacion_pila():

    print("\n=== POP DE LA PILA ===")

    operacion = pila_operaciones.pop()

    if operacion is None:

        print("\nLa pila está vacía.")

    else:

        print(
            f"\nOperación retirada: {operacion}"
        )

        registrar_log(
            "STACK_POP",
            f"Operación retirada de la pila: {operacion}"
        )


def consultar_metadatos():

    print("\n=== METADATOS DE ARCHIVOS ===")

    archivos = listar_archivos_sistema()

    archivos_existentes = []

    for archivo in archivos:

        if obtener_metadatos(archivo) is not None:
            archivos_existentes.append(archivo)

    if not archivos_existentes:

        print("\nNo existen archivos disponibles.")
        return

    print()

    for posicion, archivo in enumerate(
        archivos_existentes,
        start=1
    ):

        print(
            f"{posicion}. {archivo}"
        )

    try:

        opcion = int(
            input(
                "\nSeleccione un archivo: "
            )
        )

    except ValueError:

        print("\nDebe ingresar un número.")
        return

    if (
        opcion < 1
        or opcion > len(archivos_existentes)
    ):

        print("\nOpción inválida.")
        return

    archivo_seleccionado = (
        archivos_existentes[opcion - 1]
    )

    metadatos = obtener_metadatos(
        archivo_seleccionado
    )

    print("\n=== INFORMACIÓN DEL ARCHIVO ===")

    print(
        f"Nombre: {metadatos['nombre']}"
    )

    print(
        f"Ruta: {metadatos['ruta']}"
    )

    print(
        f"Extensión: {metadatos['extension']}"
    )

    print(
        f"Tamaño: {metadatos['tamanio']} bytes"
    )

    print(
        f"Fecha de creación: "
        f"{metadatos['fecha_creacion']}"
    )

    print(
        f"Última modificación: "
        f"{metadatos['fecha_modificacion']}"
    )

    print(
        f"Permisos: {metadatos['permisos']}"
    )

    registrar_log(
        "METADATA",
        f"Consulta de metadatos de {archivo_seleccionado}"
    )

    pila_operaciones.push(
        f"METADATA - {archivo_seleccionado}"
    )

def exportar_informacion_xml():

    print("\n=== EXPORTAR INFORMACIÓN A XML ===")

    registros = leer_registros()

    if len(registros) == 0:

        print(
            "\nNo existen registros para exportar."
        )

        registrar_log(
            "EXPORT_ERROR",
            "Intento de exportar XML sin registros"
        )

        return

    ruta = exportar_a_xml()

    registrar_log(
        "EXPORT_XML",
        f"Información exportada a {ruta}"
    )

    pila_operaciones.push(
        "EXPORT_XML - registros.xml"
    )

    print(
        "\nInformación exportada correctamente."
    )

    print(
        f"Archivo generado: {ruta}"
    )

def generar_respaldo():

    print("\n=== GENERAR RESPALDO ===")

    nombre, ruta, archivos = crear_respaldo()

    if len(archivos) == 0:

        print(
            "\nNo existen archivos para respaldar."
        )

        registrar_log(
            "BACKUP_ERROR",
            "No existían archivos para respaldar"
        )

        return

    registrar_log(
        "BACKUP",
        f"Respaldo generado: {nombre}"
    )

    pila_operaciones.push(
        f"BACKUP - {nombre}"
    )

    print(
        "\nRespaldo generado correctamente."
    )

    print(
        f"Nombre: {nombre}"
    )

    print(
        f"Ruta: {ruta}"
    )

    print("\nArchivos respaldados:")

    for archivo in archivos:
        print(f"- {archivo}")

def consultar_respaldos():

    print("\n=== RESPALDOS DISPONIBLES ===")

    respaldos = listar_respaldos()

    if not respaldos:

        print(
            "\nNo existen respaldos disponibles."
        )

        return

    for posicion, respaldo in enumerate(
        respaldos,
        start=1
    ):

        print(
            f"{posicion}. {respaldo}"
        )

def restaurar_desde_respaldo():

    print("\n=== RESTAURAR RESPALDO ===")

    respaldos = listar_respaldos()

    if not respaldos:

        print(
            "\nNo existen respaldos disponibles."
        )

        return

    print("\nRespaldos disponibles:\n")

    for posicion, respaldo in enumerate(
        respaldos,
        start=1
    ):

        print(
            f"{posicion}. {respaldo}"
        )

    try:

        opcion = int(
            input(
                "\nSeleccione el respaldo: "
            )
        )

    except ValueError:

        print(
            "\nDebe ingresar un número."
        )

        return

    if (
        opcion < 1
        or opcion > len(respaldos)
    ):

        print(
            "\nOpción inválida."
        )

        return

    respaldo_seleccionado = (
        respaldos[opcion - 1]
    )

    print(
        f"\nRespaldo seleccionado: "
        f"{respaldo_seleccionado}"
    )

    confirmacion = input(
        "¿Desea restaurarlo? (s/n): "
    ).lower()

    if confirmacion != "s":

        print(
            "\nRestauración cancelada."
        )

        return

    resultado, archivos = restaurar_respaldo(
        respaldo_seleccionado
    )

    if not resultado:

        print(
            "\nNo fue posible restaurar el respaldo."
        )

        return

    # Después de restaurar el CSV,
    # reconstruimos las estructuras derivadas.

    generar_todos_los_indices()
    generar_tabla_hash()
    guardar_hashes()

    registrar_log(
        "RESTORE",
        f"Respaldo restaurado: {respaldo_seleccionado}"
    )

    pila_operaciones.push(
        f"RESTORE - {respaldo_seleccionado}"
    )

    print(
        "\nRespaldo restaurado correctamente."
    )

    print("\nArchivos restaurados:")

    for archivo in archivos:
        print(f"- {archivo}")

    print(
        "\nÍndices reconstruidos."
    )

    print(
        "Tabla hash reconstruida."
    )

    print(
        "Hashes de integridad actualizados."
    )

def mostrar_menu():

    print("\n================================================")
    print(" SISTEMA INTEGRAL DE GESTIÓN DE INFORMACIÓN")
    print("================================================")

    print("1. Registrar información")
    print("2. Mostrar todos los registros")
    print("3. Buscar por ID")
    print("4. Buscar por atributo")
    print("5. Actualizar registro")
    print("6. Eliminar registro")

    print("7. Mostrar índice principal")
    print("8. Mostrar índice invertido")
    print("9. Buscar utilizando índice")
    print("10. Reconstruir índices")

    print("11. Mostrar tabla hash")
    print("12. Buscar utilizando hashing")
    print("13. Mostrar colisiones")

    print("14. Registrar hashes de integridad")
    print("15. Verificar integridad de archivos")

    print("16. Consultar logs")

    print("17. Mostrar pila de operaciones")
    print("18. Consultar TOP de la pila")
    print("19. Retirar operación de la pila (POP)")

    print("20. Consultar metadatos")

    print("21. Exportar información a XML")

    print("22. Generar respaldo")
    print("23. Consultar respaldos")
    print("24. Restaurar respaldo")

    print("0. Salir")

    print("================================================")


def main():

    crear_archivo_si_no_existe()
    preparar_log()

    generar_todos_los_indices()
    generar_tabla_hash()

    registrar_log(
        "SYSTEM",
        "Inicio de ejecución del sistema"
    )

    while True:

        mostrar_menu()

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            registrar_informacion()

        elif opcion == "2":
            mostrar_todos()

        elif opcion == "3":
            buscar_por_id()

        elif opcion == "4":
            buscar_por_atributo()

        elif opcion == "5":
            actualizar()

        elif opcion == "6":
            eliminar()

        elif opcion == "7":
            mostrar_indice_principal()

        elif opcion == "8":
            mostrar_indice_invertido()

        elif opcion == "9":
            buscar_utilizando_indice()

        elif opcion == "10":
            reconstruir_indices()

        elif opcion == "11":
            mostrar_tabla_hash()

        elif opcion == "12":
            buscar_utilizando_hash()

        elif opcion == "13":
            mostrar_colisiones()

        elif opcion == "14":
            registrar_integridad()

        elif opcion == "15":
            consultar_integridad()

        elif opcion == "16":
            consultar_logs()

        elif opcion == "17":
            mostrar_pila()

        elif opcion == "18":
            consultar_top()

        elif opcion == "19":
            retirar_operacion_pila()

        elif opcion == "20":
            consultar_metadatos()

        elif opcion == "21":
            exportar_informacion_xml()

        elif opcion == "22":
            generar_respaldo()

        elif opcion == "23":
            consultar_respaldos()

        elif opcion == "24":
            restaurar_desde_respaldo()

        elif opcion == "0":

            registrar_log(
                "SYSTEM",
                "Cierre normal del sistema"
            )

            print("\nPrograma finalizado.")

            break

        else:

            print("\nOpción inválida.")


if __name__ == "__main__":
    main()